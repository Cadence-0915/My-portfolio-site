$(document).ready(function(){
	$(".fury").fadeOut(2500);
	$(".iron").fadeIn(2500);
	$("#num").hide(3500);
$("body").mouseenter(function(){;
		$(".number").fadeOut(4000);
	});
});

