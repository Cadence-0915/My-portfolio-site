$(document).ready(function(){
	$(".fury").fadeOut(2100);
	$(".iron").fadeIn(2100);
	$("#num").fadeOut(6000);
	$(".sum").slideup(2400);
}
)

