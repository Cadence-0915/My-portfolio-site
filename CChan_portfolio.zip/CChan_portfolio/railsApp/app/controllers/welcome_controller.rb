class WelcomeController < ApplicationController
	def home
	end
end
