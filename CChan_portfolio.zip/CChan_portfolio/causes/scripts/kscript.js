// function newThing(){
// 	console.log("Happy Chanukkah, Jesus!");
// }

// $(document).ready(
// 	function (){
// 		alert("Document loaded");
// 	$(".section-one").fadeOut(600);
// 	$(".section-two").fadeIn(1000).animate({
// 		opacity: 0.25,
// 		width: "70%"
// 	},2000);
// 	$("#section-three").slideToggle(500).animate({
// 		opacity: 0.25,
// 		width: "70%"
// 	});

// 	$("h1").on("click", function() {
// 	 	alert("You clicked the header!");
// 	});

// 	$("body").click(
// 		function(){
// 	$(".section-one").slideUp();

// 	$("button").click(function (){
// 		// $("button").animate(function (){
			 
// 		});
// 		alert("YOU DON'T LISTEN!!!!!!");
// 	});
// });