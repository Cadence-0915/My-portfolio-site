var z = 1;

function print_it(){
	console.log(z);
}

print_it();

var z = 3;

var k = "kayla";
 
function printYourName(){
	var myNickname = "auntie kay-kay";
 	console.log(myNickname);
}
printYourName();

