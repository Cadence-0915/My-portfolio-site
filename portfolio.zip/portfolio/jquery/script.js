$(document).ready(function(){
	$(".fury").fadeOut(2100);
}
)
$(document).ready(function(){
	$(".iron").fadeIn(2100);
}
)
$(document).ready(function(){
	$("#num").fadeOut(6000);
}
)
$(document).ready(function(){
	$(".sum").slideup(2000);
}
)

